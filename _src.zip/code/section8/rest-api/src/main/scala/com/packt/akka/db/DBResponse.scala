package com.packt.akka.db

case class Created(id: String)

case object Deleted